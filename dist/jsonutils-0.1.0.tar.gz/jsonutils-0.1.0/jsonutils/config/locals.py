decimal_separator = "."
thousands_separator = ","
